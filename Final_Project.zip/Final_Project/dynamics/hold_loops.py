import numpy as np
import parameters.simulation_parameters as P

def roll_hold(phi_c, phi, p, k, flag, dt):
    '''Takes inputs of commanded roll angle, current roll angle, current angular momentum about
    x-axis, an integrator initiation flag, and the time step.
    Calculates required aileron deflection (with saturation) according to PID control
    '''

    global roll_uI
    global roll_uD
    global roll_error_d1
    
    # Upper and lower limits for aileron deflection
    limit1 = P.da_max
    limit2 = -P.da_max
    
    # Gains for aileron control loop
    kp = k[0]
    kd = k[1]
    ki = k[2]
    
    # Integrator Initialization Flag
    if flag == 1:
        roll_uI = 0
        roll_uD = 0
        roll_error_d1 = 0
    
    # Determine current error
    error = phi_c - phi

    # Find integrator, differentiator, and prior error for PID control
    roll_uI = roll_uI + (dt/2)*(error + roll_error_d1)
    roll_uD = p
    roll_error_d1 = error
    
    # PID controller
    u = kp*error + ki*roll_uI + kd*roll_uD
    
    # Saturation block
    u_sat = sat(u,limit1,limit2)

    # Integrator unwind if there is integrator control
    if ki != 0:
        roll_uI = roll_uI + dt/ki*(u_sat-u)
        
    return u_sat


def course_hold(chi_c, chi, r, k, flag, dt):
    '''Takes inputs of commanded course angle, current course angle, current angular momentum about
    z-axis, a 1x3 matrix of PID gains, an integrator initiation flag, and the time step.
    Calculates required rotation angle according to PID control
    '''

    global chi_uI
    global chi_uD
    global chi_error_d1
    
    # Upper and Lower Limits on roll angle
    limit1 = 2*np.pi
    limit2 = -2*np.pi
    
    # Gains for aileron control loop
    kp = k[0]
    kd = k[1]
    ki = k[2]
    
    # Integrator Initialization Flag
    if flag == 1:
        chi_uI = 0
        chi_uD = 0
        chi_error_d1 = 0
    
    # Determine current error
    error = chi_c - chi

    # Find integrator, differentiator, and prior error for PID control
    chi_uI = chi_uI + (dt/2)*(error + chi_error_d1)
    chi_uD = r
    chi_error_d1 = error
    
    # PID controller
    u = kp*error + ki*chi_uI + kd*chi_uD
    
    # Saturation block
    u_sat = sat(u,limit1,limit2)

    # Integrator unwind if there is integrator control
    if ki != 0:
        chi_uI = chi_uI + dt/ki*(u_sat-u)
        
    return u_sat

# def sideslip_hold(beta_c, beta, delta_beta, k, flag, dt):
#     return u_sat


def pitch_hold(theta_c, theta, q, k, flag, dt):
    '''Takes inputs of commanded pitch angle, current pitch angle, current angular momentum about
    y-body-axis, a 1x3 matrix of PID gains, an integrator initiation flag, and the time step.
    Calculates required elevator actuation (delta_e) according to PID control
    '''

    global the_uI
    global the_uD
    global the_error_d1
    
    # Upper and Lower Limits on roll angle
    limit1 = P.de_max
    limit2 = -P.de_max
    
    # Gains for aileron control loop
    kp = k[0]
    kd = k[1]
    ki = k[2]
    
    # Integrator Initialization Flag
    if flag == 1:
        the_uI = 0
        the_uD = 0
        the_error_d1 = 0
    
    # Determine current error
    error = theta_c - theta

    # Find integrator, differentiator, and prior error for PID control
    the_uI = the_uI + (dt/2)*(error + the_error_d1)
    the_uD = q
    the_error_d1 = error
    
    # PID controller
    u = kp*error + ki*the_uI + kd*the_uD
    
    # Saturation block
    u_sat = sat(u,limit1,limit2)

    # Integrator unwind if there is integrator control
    if ki != 0:
        the_uI = the_uI + dt/ki*(u_sat-u)
        
    return u_sat


def altitude_hold(h_c, h, k, flag, dt):
    '''Takes inputs of commanded height, current height, a 1x3 matrix of PID gains, 
    an integrator initiation flag, and the time step.
    Calculates required pitch angle according to PID control
    '''

    global alt_uI
    global alt_uD
    global alt_error_d1
    
    # Upper and Lower Limits on pitch angle
    limit1 = np.pi/2
    limit2 = -np.pi/2
    
    # Gains for aileron control loop
    kp = k[0]
    kd = k[1]
    ki = k[2]
    
    # Integrator Initialization Flag
    if flag == 1:
        alt_uI = 0
        alt_uD = 0
        alt_error_d1 = 0
    
    # Determine current error
    error = h_c - h
    tau = 1/P.Wh

    # Find integrator, differentiator, and prior error for PID control
    alt_uI = alt_uI + (dt/2)*(error + alt_error_d1)
    alt_uD = (2.*tau - dt)/(2.*tau + dt)*alt_uD + 2.*(error - alt_error_d1)/(2.*tau+dt)
    alt_error_d1 = error
    
    # PID controller
    u = kp*error + ki*alt_uI + kd*alt_uD
    
    # Saturation block
    u_sat = sat(u,limit1,limit2)

    # Integrator unwind if there is integrator control
    if ki != 0:
        alt_uI = alt_uI + dt/ki*(u_sat-u)
        
    return u_sat

def airspeed_hold_pitch(Va_c, Va, k, flag, dt):
    '''Takes inputs of commanded aspeed, current aspeed, a 1x3 matrix of PID gains, 
    an integrator initiation flag, and the time step.
    Calculates required pitch angle according to PID control
    '''

    global pit_uI
    global pit_uD
    global pit_error_d1
    
    # Upper and Lower Limits on pitch angle
    limit1 = np.pi/2
    limit2 = -np.pi/2
    
    # Gains for aileron control loop
    kp = k[0]
    kd = k[1]
    ki = k[2]
    
    # Integrator Initialization Flag
    if flag == 1:
        pit_uI = 0
        pit_uD = 0
        pit_error_d1 = 0
    
    # Determine current error
    error = Va_c - Va
    tau = 1/P.Wv2

    # Find integrator, differentiator, and prior error for PID control
    pit_uI = pit_uI + (dt/2)*(error + pit_error_d1)
    pit_uD = (2.*tau - dt)/(2.*tau + dt)*pit_uD + 2.*(error - pit_error_d1)/(2.*tau + dt)
    pit_error_d1 = error
    
    # PID controller
    u = kp*error + ki*pit_uI + kd*pit_uD
    # print(u)

    # Saturation block
    u_sat = sat(u,limit1,limit2)

    # Integrator unwind if there is integrator control
    if ki != 0:
        pit_uI = pit_uI + dt/ki*(u_sat-u)
        
    return u_sat

def airspeed_hold_throttle(Va_c, Va, k, flag, dt):
    '''Takes inputs of commanded aspeed, current aspeed, a 1x3 matrix of PID gains, 
    an integrator initiation flag, and the time step.
    Calculates required throttle according to PID control
    '''

    global thr_uI
    global thr_uD
    global thr_error_d1
    
    # Upper and Lower Limits on roll angle
    limit1 = 1.
    limit2 = 0.
    
    # Gains for aileron control loop
    kp = k[0]
    kd = k[1]
    ki = k[2]
    
    # Integrator Initialization Flag
    if flag == 1:
        thr_uI = 0
        thr_uD = 0
        thr_error_d1 = 0
    
    # Determine current error
    error = Va_c - Va
    tau = 1/P.Wv

    # Find integrator, differentiator, and prior error for PID control
    thr_uI = thr_uI + (dt/2)*(error + thr_error_d1)
    thr_uD = (2.*tau - dt)/(2.*tau + dt)*thr_uD + 2.*(error - thr_error_d1)/(2.*tau+dt)
    thr_error_d1 = error
    
    # PID controller
    u = kp*error + ki*thr_uI + kd*thr_uD
    
    # Saturation block
    u_sat = sat(u,limit1,limit2)

    # Integrator unwind if there is integrator control
    if ki != 0:
        thr_uI = thr_uI + dt/ki*(u_sat-u)
        
    return u_sat

# Saturation function ig
def sat(inn,up_limit,low_limit):
    if inn>up_limit:
        out=up_limit
    elif inn<low_limit:
        out=low_limit
    else:
        out=inn
    return out