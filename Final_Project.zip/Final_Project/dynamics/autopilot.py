import numpy as np
import dynamics.hold_loops as LP
import parameters.simulation_parameters as P

def autopilot(u):
    ''' d_a, d_e, d_r, d_t, phi_c, theta_c, chi_c, altitude state = autopilot(u)
    Takes arguments of the current simulation time, the current roll angle, the current pitch angle,
    the current course angle, the current angular velocities about x, y, and z body frame axes,
    the current airspeed, the current height, the commanded airspeed, the commanded height, the
    commanded course angle, and a 7x3 matrix of gains. (9 current-state, 3 commanded values, 1 array of gains).

    Calculates, with consideration taken to phase of flight (takeoff, climb, descent, hold), the required
    aileron actuation (delta_a), elevator actuation (delta_e), rudder actuation (delta_r), propellor
    actuation (delta_t), required roll angle, required pitch angle, and required course angle.
    
    Returns all calculated values and, additionally, the aircraft's current state. 
    '''

    global dt
    global altitude_state
    global init_uI
    global altitude_take_off_zone
    global altitude_hold_zone

    altitude_take_off_zone = P.TOz  # Altitude at which the craft will exit takeoff maneuvers
    altitude_hold_zone = P.Hz       # Tolerance around the commanded height that the craft will hold at
    dt = P.ts_simulation            # Time step for integrators and differentiatiors
    
    t = u[0]                        # Time?
    phi = u[1]                      # Current roll angle
    theta = u[2]                    # Current pitch angle
    chi = u[3]                      # Current flight path angle
    p = u[4]                        # Current roll momentum
    q = u[5]                        # Current pitch momentum
    r = u[6]                        # Current yaw momentum
    Va = u[7]                       # Current airspeed
    h = u[8]                        # Current height
    Va_c = u[9]                     # Commanded Airspeed
    h_c = u[10]                     # Commanded height
    chi_c = u[11]                   # Commanded flight path angle
    ks = u[12]                      # 7x3 matrix of gains for each transfer function
    
    
    # Aircraft State Machine ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if t==0:                                # IF sim just started, flag integrator for initialization
        if h <= altitude_take_off_zone:     # If craft is still taking off, indicate takeoff state
            altitude_state = 0
        elif h <= h_c - altitude_hold_zone: # If craft is below hold zone, indicate climb state
            altitude_state = 1                
        elif h >= h_c + altitude_hold_zone: # If craft is above the hold zone, indicate descend state
            altitude_state = 2
        else:                               # If the craft is within the hold zone, hold altitude and aspeed
            altitude_state = 3
        init_uI = 1
    
    # Lateral Autopilot ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if altitude_state == 0:
        if t==0:                                              # IF sim just started, flag integrator for initialization
            delta_r = 0                                       # Reset rudder deflection for calcs
            phi_c = LP.course_hold(0,chi,r,ks[1],1,dt)        # Determine commanded phi via PID
            phi_c = 0.
            delta_a = LP.roll_hold(0,phi,p,ks[0],1,dt)        # Determine commanded aileron via PID
        else:
            delta_r = 0                                       # Reset rudder deflection for calcs
            phi_c = LP.course_hold(0,chi,r,ks[1],0,dt)        # Determine commanded phi via PID
            phi_c = 0.
            delta_a = LP.roll_hold(0,phi,p,ks[0],0,dt)        # Determine commanded aileron via PID
    else:
        if t==0:                                              # IF sim just started, flag integrator for initialization
            delta_r = 0                                       # Reset rudder deflection for calcs
            phi_c = LP.course_hold(chi_c,chi,r,ks[1],1,dt)    # Determine commanded phi via PID
            delta_a = LP.roll_hold(phi_c,phi,p,ks[0],1,dt)    # Determine commanded aileron via PID
        else:
            delta_r = 0                                       # Reset rudder deflection for calcs
            phi_c = LP.course_hold(chi_c,chi,r,ks[1],0,dt)    # Determine commanded phi via PID
            delta_a = LP.roll_hold(phi_c,phi,p,ks[0],0,dt)    # Determine commanded aileron via PID

    # Longitudinal Autopilot ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if altitude_state==0:                   # IF craft is within takeoff threshold
        delta_t = 1                         # Full nuts to the propellor
        theta_c = 10*(np.pi/180)            # Commanded pitch is 10 deblees
        if h >= altitude_take_off_zone:     # If h has exceeded the takeoff zone,
            altitude_state = 1              # Transition to climb state 
            init_uI = 1                     # Reset integrator for new mode
        else:
            init_uI = 0                     # Otherwise, stay in this mode and do not reset integrator


    elif altitude_state==1:                                         # IF craft is in climb state 
        delta_t = 1                                                 # Full nuts to the propellor
        theta_c = LP.airspeed_hold_pitch(Va_c,Va,ks[5],init_uI,dt)  # Determine required theta via PID
        
        if h >= h_c - altitude_hold_zone:                           # IF craft is in hold zone 
            altitude_state = 3                                      # Transition to altitude hold state 
            init_uI = 1                                             # Reset integrator 
        elif h <= altitude_take_off_zone:                           # IF craft is still in takeoff zone, 
            altitude_state = 0                                      # Transition into takeoff mode
            init_uI = 1                                             # Reset integrator
        else:                                                       # IF craft is still in climb zone,
            init_uI = 0                                             # do not reset integrator

    elif altitude_state==2:                                         # IF craft is in descend state
        delta_t = 0                                                 # Cut propellor thrust
        theta_c = LP.airspeed_hold_pitch(Va_c,Va,ks[5],init_uI,dt)  # Determine required pitch to maintain airspeed alone
        if h <= h_c + altitude_hold_zone:                           # IF craft is within hold zone,
            altitude_state = 3                                      # Transition to altitude hold state
            init_uI = 1                                             # Reset integrator
        else:                                                       # IF craft is still above hold zone,
            init_uI = 0                                             # Reset integrator

    elif altitude_state==3:                                             # IF craft is in hold zone,
        delta_t = LP.airspeed_hold_throttle(Va_c,Va,ks[6],init_uI,dt)   # Determine required throttle via PID
        theta_c = LP.altitude_hold(h_c,h,ks[4],init_uI,dt)              # Determine required pitch via PID
        if h <= h_c - altitude_hold_zone:                               # IF craft is below hold zone,
            altitude_state = 1                                          # Transition to climb state
            init_uI = 1                                                 # Reset integrator
        elif h >= h_c + altitude_hold_zone:                             # IF craft is above hold zone,
            altitude_state = 2                                          # Transition to descend state
            init_uI = 1                                                 # Reset integrator
        else:                                                           # IF craft is still in hold zone,
            init_uI = 0                                                 # Reset integrator

    # Regardless of state (state determines theta_c)            
    if t==0:                                                    # IF the simulation has just started,
        delta_e = LP.pitch_hold(theta_c,theta,q,ks[3],1,dt)     # Determine required elevators via PID, initialize integrator
    else:                                                       # IF the simulation has been going on,
        delta_e = LP.pitch_hold(theta_c,theta,q,ks[3],0,dt)     # Determine required elevators via PID, no integrator reset
    
    return (delta_a,delta_e,delta_r,delta_t,phi_c,theta_c,chi_c,altitude_state)
